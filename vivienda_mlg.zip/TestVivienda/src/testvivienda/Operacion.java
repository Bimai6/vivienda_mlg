
package testvivienda;

public enum Operacion {
    ALQUILER, VENTA, ALQUILER_CON_OPCION_A_VENTA
}
