package testvivienda;

public class CatalogoImpl implements Catalogo {
    Piso[] lista;

    @Override
    public Piso[] getLista() {
        return lista;
    }

    @Override
    public void setLista(Piso[] lista) {
        this.lista = lista;
    }
}
