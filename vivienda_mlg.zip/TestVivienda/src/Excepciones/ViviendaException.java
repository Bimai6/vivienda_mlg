package Excepciones;

//5
/**
 * Clase usada para manejar excepciones de la clase Vivienda
 * @author Mario Lebrero García
 */
public class ViviendaException extends Exception {
    public ViviendaException(String s){
        System.out.println(s);
    }
}
